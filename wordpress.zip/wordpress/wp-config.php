<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp-dp' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '^Zjoc-)mYfh;4nf&:]nU/Lm)k4MK%W O1[vm[Kq#}iNVYpHHH9HB&Tu[=:)j^a:1' );
define( 'SECURE_AUTH_KEY',  'eTFH<9zh7ISbo/37{ou3uAFN)Ks!|n8?nZ1`;&P28]1HTu3=3woZf?!Tn~,`M|.y' );
define( 'LOGGED_IN_KEY',    'tvE4]Q1+4~&8m=lbY2aLT1YNG;8rGm`4trsGXiYrv|Ih#<ma3zI}|YUU[R_4ch;b' );
define( 'NONCE_KEY',        ':R> |Oz1!.]:{ KbQI(I5|cPSXuL*AVAS1_`4t/wh8;QhdI;Ms{/$Bb#OjZT%d[(' );
define( 'AUTH_SALT',        'O%e|0O.v<>}hd48x&s>[o:Y7n@~4X_>Po<7>wz{:Ro:/3@s~<:zlVsqpI(5gkt5B' );
define( 'SECURE_AUTH_SALT', '|loI-V8:DG.fX/r}T`4h6=>kfTwfa}Wbd@J,[LmxC/&su!`Y8A0/{0rEwLX|?m+-' );
define( 'LOGGED_IN_SALT',   '.LG,7L|:;4}Fh{2if+EnfSCP4=-rDmqzh<N;WDMy}P6Pz>QV7&vdBb8o2_3YEN>X' );
define( 'NONCE_SALT',       '0qff[/6oCT1QnZC;(%|p:PZ-eQL`LJQ:p:SqZmt1.2v%48tXOY{{GeT&~`Jfvv.(' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
